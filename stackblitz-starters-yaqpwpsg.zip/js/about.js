import { initNav } from './components/nav.js';
import { initAbout } from './components/about.js';

document.addEventListener('DOMContentLoaded', () => {
  initNav();
  initAbout();
});