import { initNav } from './components/nav.js';
import { initContactPage } from './components/contact-page.js';

document.addEventListener('DOMContentLoaded', () => {
  initNav();
  initContactPage();
});