import { initNav } from './components/nav.js';
import { initProjects } from './components/projects.js';
import { initContact } from './components/contact.js';

document.addEventListener('DOMContentLoaded', () => {
  initNav();
  initProjects();
  initContact();
});