export function initContact() {
  const contact = document.getElementById('contact');
  contact.innerHTML = `
    <h2>Get In Touch</h2>
    <div class="contact-links">
      <a href="mailto:your.email@example.com">Email</a>
      <a href="https://github.com" target="_blank">GitHub</a>
      <a href="https://linkedin.com" target="_blank">LinkedIn</a>
    </div>
  `;
}