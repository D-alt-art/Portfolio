export function initProjects() {
  const projects = document.getElementById('projects');
  projects.innerHTML = `
    <h2>My Projects</h2>
    <div class="project-grid">
      <article class="project-card">
        <h3>Project 1</h3>
        <p>A brief description of your first project goes here.</p>
        <div class="tech-stack">
          <span>React</span>
          <span>Node.js</span>
        </div>
      </article>

      <article class="project-card">
        <h3>Project 2</h3>
        <p>A brief description of your second project goes here.</p>
        <div class="tech-stack">
          <span>TypeScript</span>
          <span>Express</span>
        </div>
      </article>

      <article class="project-card">
        <h3>Project 3</h3>
        <p>A brief description of your third project goes here.</p>
        <div class="tech-stack">
          <span>Python</span>
          <span>Django</span>
        </div>
      </article>
    </div>
  `;
}