export function initNav() {
  const nav = document.getElementById('main-nav');
  nav.innerHTML = `
    <a href="/" ${location.pathname === '/' ? 'aria-current="page"' : ''}>Portfolio</a>
    <a href="/page2.html" ${location.pathname === '/page2.html' ? 'aria-current="page"' : ''}>About</a>
    <a href="/contact.html" ${location.pathname === '/contact.html' ? 'aria-current="page"' : ''}>Contact</a>
  `;
}