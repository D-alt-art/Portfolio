import { validateEmail } from '../utils/validation.js';

export function initContactPage() {
  const contactPage = document.getElementById('contact-page');
  contactPage.innerHTML = `
    <div class="contact-page">
      <h1>Get in Touch</h1>
      <div class="contact-content">
        <form id="contact-form" class="contact-form">
          <div class="form-group">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" required>
          </div>
          <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>
          </div>
          <div class="form-group">
            <label for="message">Message</label>
            <textarea id="message" name="message" rows="5" required></textarea>
          </div>
          <button type="submit">Send Message</button>
        </form>
        
        <div class="contact-info">
          <h2>Other Ways to Connect</h2>
          <div class="social-links">
            <a href="https://github.com" target="_blank" class="social-link">
              <span>GitHub</span>
            </a>
            <a href="https://linkedin.com" target="_blank" class="social-link">
              <span>LinkedIn</span>
            </a>
            <a href="https://twitter.com" target="_blank" class="social-link">
              <span>Twitter</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  `;

  setupFormHandling();
}

function setupFormHandling() {
  const form = document.getElementById('contact-form');
  
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(form);
    const email = formData.get('email');
    
    if (!validateEmail(email)) {
      alert('Please enter a valid email address');
      return;
    }
    
    // In a real application, you would send this data to your backend
    console.log({
      name: formData.get('name'),
      email: formData.get('email'),
      message: formData.get('message')
    });
    
    form.reset();
    alert('Message sent successfully!');
  });
}