export function initAbout() {
  const about = document.getElementById('about');
  about.innerHTML = `
    <h1>About Me</h1>
    <div class="about-content">
      <p>Hello! I'm a passionate developer with expertise in building web applications. I love creating elegant solutions to complex problems.</p>
      
      <h2>Skills</h2>
      <div class="skills-grid">
        <div class="skill-category">
          <h3>Frontend</h3>
          <ul>
            <li>HTML5 & CSS3</li>
            <li>JavaScript/TypeScript</li>
            <li>React</li>
          </ul>
        </div>
        <div class="skill-category">
          <h3>Backend</h3>
          <ul>
            <li>Node.js</li>
            <li>Python</li>
            <li>SQL</li>
          </ul>
        </div>
      </div>

      <h2>Experience</h2>
      <div class="experience">
        <div class="experience-item">
          <h3>Senior Developer</h3>
          <p>Company Name • 2020-Present</p>
          <p>Brief description of your role and achievements.</p>
        </div>
      </div>
    </div>
  `;
}