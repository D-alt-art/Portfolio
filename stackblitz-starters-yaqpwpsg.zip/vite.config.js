import { defineConfig } from 'vite';

export default defineConfig({
  build: {
    outDir: 'dist',
    rollupOptions: {
      input: {
        main: 'index.html',
        contact: 'contact.html',
        page2: 'page2.html'
      }
    }
  }
});